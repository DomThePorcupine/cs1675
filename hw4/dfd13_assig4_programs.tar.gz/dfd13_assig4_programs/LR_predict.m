function y = LR_predict(X, weights)
  % This is simply the opposite of the operation
  % that we did before
  y = X * weights;
end
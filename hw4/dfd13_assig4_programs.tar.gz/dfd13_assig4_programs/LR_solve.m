function weights = LR_solve(X, y)
  % Weights as defined by the homework
  % assignment
  weights = X\y;
end
function scatter_plot(attribute_1, attribute_2)
    scatter(attribute_1, attribute_2, 'filled')
end